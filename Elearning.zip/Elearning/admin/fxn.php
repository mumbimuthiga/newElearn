
	<?php
	
	function  view_cat() {
		//include("db2.php");
		$i=1;
	$get_cat=$conn->prepare("select * from categorys");
	$get_cat->setFetchMode(PDO:: FETCH_ASSOC);
	$get_cat->execute();
	while($row=$get_cat->fetch()):
		echo "<tr>
	
		<td>".$row['cat_name']."</td>

		</tr>";
	endwhile;
}


?>
	
	