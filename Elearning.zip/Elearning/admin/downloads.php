<?php include 'filesLogic.php';?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
 
  <title>Add Category</title>
</head>
<body>
  <h2>Category</h2>
  <style >
    
    body{
      background: #fff;
}
h2{
  color: black;
  text-align: left;
  margin-top: 5px;
  text-shadow: 3px 3px 3px #000;
  line-height: 60px;
}
form {
  width: 250px;
  height: 1020px;
  margin-top: 10px;
  margin: 5px auto;
  
  padding: 30px;
  border: 1px solid #555;
  background: #3f5267;
  display: inline-block;
  overflow-x: auto;
  text-align: center;
  color: #fff;

  outline: none;
  float: left;
 

}
  </style>

<form>

  
    
   

  <?php foreach ($files as $file): ?>
    
      
     <?php echo $file['name']; ?>
      <?php echo floor($file['size'] / 1000) . ' KB'; ?>
    
      <a href="downloads.php?file_id=<?php echo $file['id'] ?>">Download</a>
    
  <?php endforeach;?>


</form>

</body>
</html>
