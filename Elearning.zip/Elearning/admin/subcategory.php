<?php


?>
<div  id="bodyright">
	<h3>View All Categories</h3>
	<div id="add">
		<details>
			<summary>Add Category</summary>
			<form method="post" enctype="multipart/form-data">
				<input type="text" name="catname"  placeholder="Enter Category Name Here"value="$catname">
				<center><button name ="add_cat">Add Category</button></center>
			</form>
		</details>
		</div>
	</div>
	<?php
	$catname=_POST['catname'];
// connect to the database
$conn = mysqli_connect('localhost', 'root', '', 'elearning');

$sql = "SELECT name  FROM categorys";
$result = mysqli_query($conn, $sql);

$files = mysqli_fetch_all($result, MYSQLI_ASSOC);

// Uploads files
if (isset($_POST['add_cat'])) { // if save button on the form is clicked
    
       
            $sql = "INSERT INTO categorys (name) VALUES('$_POST[catname]')";
            if (mysqli_query($conn, $sql)) {
                echo "<script type='text/javascript'>alert('submitted successfully!')</script>";
             
             header("Location:/elearning/admin"); 

               // echo "File uploaded successfully";
            }
         else {
              echo "<script type='text/javascript'>alert('Failed to upload file.!')</script>";
            //echo "Failed to upload file.";
        }
    }



<?php


?>
<div  id="bodyright">
	<h3>View All Categories</h3>
	<div id="add">
		<details>
			<summary>Add SubCategory</summary>
			<form method="post" enctype="multipart/form-data">
				<input type="text" name="subcatname"  placeholder="Enter SubCategory Name Here"value="$catname">
				<center><button name ="add_cat">Add SubCategory</button></center>
			</form>
		</details>
		</div>
	</div>
	<?php
	$catname=_POST['subcatname'];
// connect to the database
$conn = mysqli_connect('localhost', 'root', '', 'elearning');

$sql = "SELECT name  FROM categorys";
$result = mysqli_query($conn, $sql);

$files = mysqli_fetch_all($result, MYSQLI_ASSOC);

// Uploads files
if (isset($_POST['add_cat'])) { // if save button on the form is clicked
    
       
            $sql = "INSERT INTO categorys (name) VALUES('$_POST[subcatname]')";
            if (mysqli_query($conn, $sql)) {
                echo "<script type='text/javascript'>alert('submitted successfully!')</script>";
             
             header("Location:/elearning/admin"); 

               // echo "File uploaded successfully";
            }
         else {
              echo "<script type='text/javascript'>alert('Failed to upload file.!')</script>";
            //echo "Failed to upload file.";
        }
    }



