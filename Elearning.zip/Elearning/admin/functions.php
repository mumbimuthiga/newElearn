<?php
 /*function view_cat(){
 	//include ("db.php");
 	include("db2.php");
$count = 0;
$query = mysqli_query($con,"SELECT * FROM categorys");
foreach($query as $row){
 $count++;
?>


<?php echo $row["name"]; ?>

<?php
if($count >0 ) { 
// three items in a row
	echo"<option value='".$row['cat_id']."'>".$row['name']."</option>";
        //echo '</tr><tr>';
        $count = 0;
    }
}

 }
 



?>
*/