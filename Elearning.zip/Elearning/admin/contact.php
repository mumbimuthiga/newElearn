<?php


//include("function.php");

?>
<div  id="bodyright">
	<h3>Contact Us Page</h3>
	<div id="contact">
	<form method="post" enctype="multipart/form-data">
		<table>
		<tr>
			<td>Update Contact No.</td>
			<td><input type="tel" name="phn"></td>
		</tr> 
		<tr>
			<td>Update Email.</td>
			<td><input type="email" name="email"></td>
		</tr> 
		<tr>
			<td>Update Office Address Line 1.</td>
			<td><input type="tel" name="add1"></td>
		</tr> 
		<tr>
			<td>Update Office Address Line 2.</td>
			<td><input type="tel" name="add2"></td>
		</tr> 
		<tr>
			<td>http://facebook.com</td>
			<td><input type="text" name="fb"></td>
		</tr>
		<tr>
			<td>Update twitter.com</td>
			<td><input type="text" name="twit"></td>
		</tr> 
		<tr>
			<td>http://googleplus.co.ke.</td>
			<td><input type="text" name="gp"></td>
		</tr>  
</table>

<center><button name ="add_cat">Save</button></center>
			</form>
		

	
</div>
	</div>
	<?php
	//$catname=_POST['catname'];
// connect to the database
$conn = mysqli_connect('localhost', 'root', '', 'elearning');

$sql = "SELECT name  FROM categorys";
$result = mysqli_query($conn, $sql);

$files = mysqli_fetch_all($result, MYSQLI_ASSOC);

// Uploads files
if (isset($_POST['add_cat'])) { // if save button on the form is clicked
    
       
            $sql = "INSERT INTO contact (contactno ,email ,add1 ,add2 ,facebook,twitter ,googleplus) VALUES('$_POST[tel]' ,'$_POST[email]','$_POST[add1]','$_POST[add2]','$_POST[fb]' ,'$_POST[twit]' ,'$_POST[gp]')";
            if (mysqli_query($conn, $sql)) {
                echo "<script type='text/javascript'>alert('submitted successfully!')</script>";
             
             header("Location:/elearning/admin"); 

               // echo "File uploaded successfully";
            }
         else {
              echo "<script type='text/javascript'>alert('Failed to upload file.!')</script>";
            //echo "Failed to upload file.";
        }
    }
    ?>



