<?php if(!isset($_GET['downloads']) && !isset($_GET['contact']) && !isset($_GET['sub_cat']) && !isset($_GET['cat']) && !isset($_GET['terms']))
{
	?>
 <div id='bodyright'>
	<h3>OverView</h3>
</div>
<?php }?>