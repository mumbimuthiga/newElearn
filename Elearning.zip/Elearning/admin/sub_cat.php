
<div  id="bodyright">
	<h3>View All Categories</h3>
	<div id="add">
	<div id="sub_cat">
		<details>
			<summary>Add SubCategory</summary>
			<form method="post" enctype="multipart/form-data">

				<select name="cat_id">
					<option>Select Category</option>


					<?php
					
		include('db2.php');


$status = '';
if (!empty($_POST['sports'])){
if (is_array($_POST['sports'])) {
//$status = "<strong>You selected the below Category:</strong><br />";
//foreach($_POST['sports'] as $sport_id){
$query = mysqli_query($con,"SELECT * FROM categorys");
$row = mysqli_fetch_assoc($query);

$status .= $row['sport_name'] . "<br />";
   } 
  } 

?>
<?php
$count = 0;
$query = mysqli_query($con,"SELECT * FROM categorys");
foreach($query as $row){
 $count++;
?>


<?php echo $row["name"]; ?>

<?php
if($count >0 ) { 
// three items in a row
	echo"<option value='".$row['cat_id']."'>".$row['name']."</option>";
        //echo '</tr><tr>';
        $count = 0;
    }
} ?>

</form>
 
<br />
<?php echo $status; ?>

	
	?>
					
				</select>
				
			
				<input type="text" name="subcatname"  placeholder="Enter SubCategory Name Here">
				<center><button name ="addsub_cat">Add Category</button></center>
			
		
				
			</form>
		</details>
		</div>
	</div>
</div>

	
	
<?php
	//$catname=_POST['subcatname'];
// connect to the database
$conn = mysqli_connect('localhost', 'root', '', 'elearning');

$sql = "SELECT name  FROM subcategorys";
$result = mysqli_query($conn, $sql);

//$files = mysqli_fetch_all($result, MYSQLI_ASSOC);

// Uploads files
if (isset($_POST['addsub_cat'])) { // if save button on the form is clicked
    
       
            $sql = "INSERT INTO subcategorys (sub_cat_name ,cat_id) VALUES('$_POST[subcatname]' ,'$_POST[cat_id]')";
            if (mysqli_query($conn, $sql)) {
                echo "<script type='text/javascript'>alert('submitted successfully!')</script>";
             
             header("Location:/elearning/admin"); 

               // echo "File uploaded successfully";
            }
         else {
              echo "<script type='text/javascript'>alert('Failed to upload file.!')</script>";
            //echo "Failed to upload file.";
        }
    }


	