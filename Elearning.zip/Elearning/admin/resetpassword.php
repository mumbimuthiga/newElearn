<!DOCTYPE html>
<html>
<head>
	<title>Reset Password</title>
</head>
<body>
	<h1>Reset Password</h1>
	<p>An email will be send to you with instruction to reset your password</p>
	<form action="reset-request.php" method="post">
		<input type="email" name="email" placeholder="Enter your email address">
		<button type="submit" name="reset-request-submit">Reset Password</button>
		
	</form>

</body>
</html>