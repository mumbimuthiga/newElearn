<?php 
//include('server.php')
?>



<!DOCTYPE html>
<html>
<head>
	<title>Registration Form</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<style type="text/css">
	*{
		margin: 0px;
		padding:0px;
	}
	body {
		font-size: 120%;
		background: #F8F8FF;

	}
	.header{
		width:30%;
		margin:50px auto 0px;
		color:white;
		background: #5F9EA0;
		text-align: center;
		border: 1px solid #B0C4DE;
		border-bottom: none;
		border-radius: 10px 10px 0px 0px;
		padding: 20px;
	}
	form ,.content {
		width: 30%;
		margin: 0px auto;
		padding:20px;
		border: 1px solid #B0C4DE;
		background: white;
		border-radius: 0px 0px 10px 10px;
	}
	.input-group{
		margin: 0px 0px 10px 10px;
	}
	.input-group label{
		display: block;
		text-align: left;
		margin: 3px;
	}
	.input-group input{
		height: 20px;
		width: 80%;
		padding:5px 10px;
		font-size: 16px;
		border-radius: 5px;
		border: 1px solid gray;
	}
	.select  option{
    cursor:pointer;
    display:inline-block;
    position:relative;
    font:normal 11px/22px Arial, Sans-Serif;
    color:black;
    border:1px solid #ccc;
    width: 80%;
}
	.btn{
		padding: 10px;
		font-size: 15px;
		color:white;
		background: #5F9EA0;
		border: none;
		border-radius: 5px;
	}
	.error{
		width:92%;
		margin: 0px auto;
		padding:10px;
		border: 1px solid #a94442;
		color: #a94442;
		background: #f2dede;
		border-radius: 5px;
		text-align: left;
	}
	.success{
		color: #3c763d;
		background: #dff0d8;
		border: 1px solid #3c763d;
		margin-bottom: 20px;
	}
	



	</style>
<div class ="header">
	<h2>Register</h2>
</div>
<form method="post" action="register.php">

<div class="input-group">
	<select name="Level">

  <option value="">Select...</option>

  <option value="Silver">Silver</option>

  <option value="Gold">Gold</option>
  <option value="Platinum">Platinum</option>


</select>
</div>


  <div class="input-group">
<label>Username</label>
<input type="text" name="username"value="">
  </div>
<div class="input-group">
	<label>Email</label>
	<input type="email" name="email" value="">
</div>
<div class="input-group">
<label>Password </label>
<input type="password"name="password_1">
</div>

<div class="input-group">
	<label>Confirm Password </label>
	<input type="password"name="password_2">
</div>
<div class="input-group">
	<button type="submit" class="btn" name="reg_user">Register </button>
	</div>
	<p>Already a member? <a href="login.php">Signin</a>
	</p>
</form>

</body>
</html> 

 
<?php
	//$catname=_POST['catname'];
// connect to the database
$conn = mysqli_connect('localhost', 'root', '', 'elearning');

$sql = "SELECT name  FROM categorys";
$result = mysqli_query($conn, $sql);

$files = mysqli_fetch_all($result, MYSQLI_ASSOC);

// Uploads files
if (isset($_POST['reg_user'])) { // if save button on the form is clicked
    
       
            $sql = "INSERT INTO users ( level ,username ,email ,password ,confpassword) VALUES('$_POST[Level]','$_POST[username]' ,'$_POST[email]','$_POST[password_1]','$_POST[password_2]')";
            if (mysqli_query($conn, $sql)) {
                echo "<script type='text/javascript'>alert('submitted successfully!')</script>";
             
             header("Location:/elearning/admin"); 

               // echo "File uploaded successfully";
            }
         else {
              echo "<script type='text/javascript'>alert('Failed to upload file.!')</script>";
            //echo "Failed to upload file.";
        }
    }
    ?>
