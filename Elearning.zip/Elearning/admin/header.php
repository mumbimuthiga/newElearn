 <?php  include("function.php");
 //include("login.php");
  ?>

<div id="header">
 	<div id="logo">
 		<h2><a href="index.php"> ELearning </a></h2>
 	</div>
 	<div id="title">
 		 <h2>Admin Panel of Elearning System</h2>
 	</div>
 	
 	<div id="link">
 		
 		<h3><a href="#">SignUp</a></h3>
 	</div>
 		
 	
 		
 	</div>
 </div>