<div id="bodyleft">
	<h3>Categories Management</h3>
	<ul>
		<li><a href="index.php"> <i class="fas fa-home"></i> Dashboard</a>
		<li><a href="index.php?cat"> Add Categories</a> 
		<li><a href="index.php?sub_cat"> Add SubCategories</a>
			
	<h3>Courses Management</h3>
	<ul>
		<li><a href="#">Active Courses</a>
		<li><a href="#">Pending Courses</a>
		<li><a href="#">Unpublish Courses</a>
		<li><a href="#">Advanced Courses</a>
	</ul>
	<h3>Delivery</h3>
	<ul>
		<li><a href="#">DVDS/CDS</a>
		<li><a href="#">Notes</a>
		<li><a href="file-uploaded-download/uploads/index3.php">Papers</a>
		
	</ul>
	<h3>User Management </h3>
	<ul>
		<li><a href="downloads.php">Silver Downloads</a>
		<li><a href="#">Gold Downloads</a>
		<li><a href="#">Platinum Downloads</a>
	</ul>
	<h3>Payment Management</h3>
	<ul>
		<li><a href="#">Silver Payment</a>
		<li><a href="#">Gold Payment</a>
		<li><a href="#"> Platinum Payment  </a>
	</ul>
	<h3>Pages Management</h3>
	<ul>
		<li><a href="index.php?terms">Terms & Conditions</a>
		<li><a href="index.php?contact">Contact Us Page</a>
		<li><a href="index.php?about"> About Us </a>
		<li><a href="index.php?faqs">FAQS Page</a>
		<li><a href="#"> Edit Slider  </a>

	</ul>
</div>

<?php
if(isset($_GET['cat'])) {
	include("cat.php");
}
if(isset($_GET['sub_cat'])) {
	include("sub_cat.php");
}
if(isset($_GET['terms'])) {
	include("terms.php");
}

if(isset($_GET['contact'])) {
	include("contact.php");
}


?>