<?php
 
//connect.php
 
/**
 * This script connects to MySQL using the PDO object.
 * This can be included in web pages where a database connection is needed.
 * Customize these to match your MySQL database connection details.
 * This info should be available from within your hosting panel.
 */
 
//Our MySQL user account.
//define('MYSQL_USER', 'root');
 
//Our MySQL password.
//define('MYSQL_PASSWORD', '');
 
//The server that MySQL is located on.
//define('MYSQL_HOST', 'localhost');
 
//The name of our database.
//define('MYSQL_DATABASE', 'elearning');
 
/**
 * PDO options / configuration details.
 * I'm going to set the error mode to "Exceptions".
 * I'm also going to turn off emulated prepared statements.
 */
$hostname='localhost';
$db='elearning';
$Username='root';
$Password='';
try{
	$dsn="mysql:host=".$hostname.";db=".$db;
	$pdo=new PDO($dsn ,$Username ,$Password);
	

} catch (PDOException $e){
	echo"DB Connection Failed" .$e->getmessage();

}







/*$pdoOptions = array(
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_EMULATE_PREPARES => false
);
 
/**
 * Connect to MySQL and instantiate the PDO object.
 
$con = new PDO("mysql:host=$hostname; dbname=$db", $Username,$Password);
 
//The PDO object can now be used to query MySQL.
*/