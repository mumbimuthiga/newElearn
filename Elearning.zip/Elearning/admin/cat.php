<?php


//include("fxn.php");

?>
<div  id="bodyright">
	<div  id="cat">
	<h3>View All Categories</h3>
	<div id="add">
		<details>
			<summary>Add Category</summary>
			<form method="post" enctype="multipart/form-data">
				<input type="text" name="catname"  placeholder="Enter Category Name Here"value="$catname">
				<center><button name ="add_cat">Add Category</button></center>
			</form>
		</details>
<table cellspacing="0">
	<tr>
		
		<th> Category Name</th>
		<th>Edit</th>
		<th> Delete</th>
	</tr>
	<?php 
	//<td>".$row['cat_name']."</td>
	//echo view_cat() ?>
	<td></td>

</table>
	<?php
	

 	//include ("db.php");
 	include("db2.php");
 	//$i=1;
echo "<tr>


</tr>";
$count = 0;
$query = mysqli_query($con,"SELECT * FROM categorys");
foreach($query as $row){
 $count++;
?>


<?php 
echo $row["name"];
 ?>

<?php
if($count >0 ) { 
// three items in a row
	echo"<option value='".$row['cat_id']."'>".$row['name']."</option>";
        //echo '</tr><tr>';
        $count = 0;
    }
}

 
 



?>

	
</div>

</div>
	</div>
	<?php
	//$catname=_POST['catname'];
// connect to the database
$conn = mysqli_connect('localhost', 'root', '', 'elearning');

$sql = "SELECT name  FROM categorys";
$result = mysqli_query($con, $sql);

$files = mysqli_fetch_all($result, MYSQLI_ASSOC);

// Uploads files
if (isset($_POST['add_cat'])) { // if save button on the form is clicked
    
       
            $sql = "INSERT INTO categorys (name) VALUES('$_POST[catname]')";
            if (mysqli_query($conn, $sql)) {
                echo "<script type='text/javascript'>alert('submitted successfully!')</script>";
             
             header("Location:/elearning/admin"); 

               // echo "File uploaded successfully";
            }
         else {
              echo "<script type='text/javascript'>alert('Failed to upload file.!')</script>";
            //echo "Failed to upload file.";
        }
    }
    
    ?>



