<?php
$to="0723782739 @vtext.com";
$from="veronica@intelliplus.co.ke" ;
$message="3306";
$headers="From: $from \n";
mail($to ,'' ,$message ,$headers);
?>