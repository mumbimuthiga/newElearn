<!DOCTYPE html>
<html>
<head>
	<title>Admin  |Home</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>

<?php 
include('header.php');
include('bodyleft.php');
include('bodyright.php');
include('function.php');
//include ('contact.php');
//include ('cat.php');
//include ('sub_cat.php');
//include("category.php");
//include("index3.php");
//include('file-uploaded-download\index.php');
//include("downloads3.php");
?>
</body>
</html>