<!DOCTYPE html>
include('db.php');
		$get_cat=$con->prepare("select * from categorys");
		$get_cat->setFetchMode(PDO::FETCH_ASSOC);
		$get_cat->execute();
		while($row=$get_cat->fetch()):
			echo"<option>".$row['name']."</option>";
		endwhile;













<html>
<head>
	<title></title>
</head>
<style>
table td {
    border-bottom: 1px solid #f1f1f1;
}
</style>
<body>
	<form name="form" method="post" action="">
<label><strong>Select Category:</strong></label><br />
<option>Select Category</option>

	<?php
include('db2.php');


$status = '';
if (!empty($_POST['sports'])){
if (is_array($_POST['sports'])) {
$status = "<strong>You selected the below Category:</strong><br />";
foreach($_POST['sports'] as $sport_id){
$query = mysqli_query($con,"SELECT * FROM categorys WHERE `id`='$sport_id'");
$row = mysqli_fetch_assoc($query);

$status .= $row['sport_name'] . "<br />";
   } 
  } 
} 
?>
<?php
$count = 0;
$query = mysqli_query($con,"SELECT * FROM categorys");
foreach($query as $row){
 $count++;
?>


<?php echo $row["name"]; ?>

<?php
if($count == 3) { 
// three items in a row
	echo"<option>".$row['name']."</option>";
        //echo '</tr><tr>';
        $count = 0;
    }
} ?>

</form>
 
<br />
<?php echo $status; ?>

</body>
</html>
