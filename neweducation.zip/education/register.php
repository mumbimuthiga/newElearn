<?php 
//include('server.php')
?>



<!DOCTYPE html>
<html>
<head>
	<title>Registration Form</title>

	<link rel="stylesheet" type="text/css" href="style.css">
	<link rel="stylesheet" href="css/linearicons.css">
			<link rel="stylesheet" href="css/font-awesome.min.css">
			<link rel="stylesheet" href="css/bootstrap.css">
			<link rel="stylesheet" href="css/magnific-popup.css">
			<link rel="stylesheet" href="css/nice-select.css">							
			<link rel="stylesheet" href="css/animate.min.css">
			<link rel="stylesheet" href="css/owl.carousel.css">			
			<link rel="stylesheet" href="css/jquery-ui.css">
			<link rel="stylesheet" href="css/main.css">


</head>
<body>
	<style type="text/css">
	*{
		margin: 0px;
		padding:0px;
	}
	body {
		font-size: 120%;
		background: url("img/link.jpg") no-repeat;

	}
	.header{
		width:30%;
		margin:30px auto 0px;
		color:white;
		background: #5F9EA0;
		text-align: center;
		border: 1px solid #B0C4DE;
		border-bottom: none;
		border-radius: 10px 10px 0px 0px;
		padding: 20px;
	}
	form ,.content {
		width: 30%;
		height: 100%;
		margin: 0px auto;
		padding:20px;
		border: 1px solid #B0C4DE;
		background: #F8F8FF;
	
		border-radius: 0px 0px 10px 10px;
	}
	.input-group{
		margin: 0px 0px 10px 10px;
	}
	.input-group label{
		display: block;
		text-align: left;
		margin: 3px;
	}
	.input-group input{
		height: 40px;
		width: 90%;
		padding:5px 10px;
		font-size: 16px;
		border-radius: 5px;
		border: 1px solid gray;
	}
	.select  option{
    cursor:pointer;
    display:inline-block;
    position:relative;
    font:normal 11px/22px Arial, Sans-Serif;
    color:black;
    border:1px solid #ccc;
    width: 80%;
}
	.btn{
		padding: 10px;
		font-size: 15px;
		color:white;
		background: #5F9EA0;
		border: none;
		border-radius: 5px;
	}
	.error{
		width:92%;
		margin: 0px auto;
		padding:10px;
		border: 1px solid #a94442;
		color: #a94442;
		background: #f2dede;
		border-radius: 5px;
		text-align: left;
	}
	.success{
		color: #3c763d;
		background: #dff0d8;
		border: 1px solid #3c763d;
		margin-bottom: 20px;
	}

	

</style>

<div class="header-top">
	  			<div class="container">
			  		<div class="row">
			  			<div class="col-lg-6 col-sm-6 col-8 header-top-left no-padding">
			  						
			  			</div>
			  			<div class="col-lg-6 col-sm-6 col-4 header-top-right no-padding">
			  				<a href="tel:+953 012 3654 896"><span class="lnr lnr-phone-handset"></span> <span class="text">+254723782739</span></a>
			  				<a href="mailto:support@colorlib.com"><span class="lnr lnr-envelope"></span> <span class="text">support@edukate.com</span></a>			
			  			</div>
			  		</div>			  					
	  			</div>
			</div>
		    <div class="container main-menu">
		    	<div class="row align-items-center justify-content-between d-flex">
			      <div id="logo">
			        <a href="index.html"><img src="img/logo.png" alt="" title="Edukate" /></a>
			      </div>
			      <nav id="nav-menu-container">
			        <ul class="nav-menu">
			          <li><a href="index.html">Home</a></li>
			          <li><a href="about.html">About</a></li>
			          <li><a href="courses.html">Levels</a>
			          	<ul>
			          	<li><a href="KCPE.html">KCPE PAPERS</a></li>
			              <li><a href="kcse.html">KCSE PAPERS</a></li>
			               <li><a href="insit1.html">INSTITUTIONS</a></li>
                       </ul>



			          </li>
			         
			          <li><a href="">Results</a></li>
			          <li class="menu-has-children"><a href="">Register</a>
			            <ul>
			              <li><a href="register.php">Gold MemberShip</a></li>
			              <li><a href="platinumregister.php">Platinum MemberShip</a></li>
			              <li><a href="silverregister.php">Silver MemberShip</a></li>
			            </ul>
			          </li>	
			          <li class="menu-has-children"><a href="">Login</a>
			            <ul>
		              		<li><a href="login.php">Gold MemberShip</a></li>		
		              		<li><a href="login.php">Platinum MemberShip</a></li>		
			                <li><a href="login.php">Silver Membership</a></li>
					          				                		
			            </ul>
			          </li>					          					          		          
			          <li><a href="contact.html">Contact</a></li>
			        </ul>
			      </nav><!-- #nav-menu-container -->		    		
		    	</div>
		    </div>
		  </header><!-- #header -->


<div class ="header">
	<h2>Register</h2>
</div>
<form method="post" action="register.php">



  <div class="input-group">
<label>Username</label>
<input type="text" name="username"value="">
  </div>
<div class="input-group">
	<label>Email</label>
	<input type="email" name="email" value="">
</div>
<div class="input-group">
<label>Password </label>
<input type="password"name="password_1">
</div>

<div class="input-group">
	<label>Confirm Password </label>
	<input type="password"name="password_2">
</div>
<div class="input-group">
	<button type="submit" class="btn" name="reg_user">Register </button>
	</div>
	<p>Already a member? <a href="login.php">Signin</a>
	</p>
</form>

</body>
</html> 

 
<?php
	//$catname=_POST['catname'];
// connect to the database
$conn = mysqli_connect('localhost', 'root', '', 'elearning');

$sql = "SELECT name  FROM categorys";
$result = mysqli_query($conn, $sql);

$files = mysqli_fetch_all($result, MYSQLI_ASSOC);

// Uploads files
if (isset($_POST['reg_user'])) { // if save button on the form is clicked
    
       
            $sql = "INSERT INTO users ( username ,email ,password ,confpassword) VALUES('$_POST[username]' ,'$_POST[email]','$_POST[password_1]','$_POST[password_2]')";
            if (mysqli_query($conn, $sql)) {
                echo "<script type='text/javascript'>alert('submitted successfully!')</script>";
             
             header("Location:/education/index.html"); 

               // echo "File uploaded successfully";
            }
         else {
              echo "<script type='text/javascript'>alert('Failed to upload file.!')</script>";
            //echo "Failed to upload file.";
        }
    }
    ?>
</section>
