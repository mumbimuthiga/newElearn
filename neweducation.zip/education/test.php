<!DOCTYPE html>
<html>
<head>
	<title>Download</title>
</head>
<style type="text/css">
	
	table{
		 font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
	}
	 table th td {
		 border: 1px solid #ddd;
  padding: 8px;
	}
	tr:nth-child(even) {
		background-color: #f2f2f2;
	}
	td{
		 border: 1px solid #ddd;
  padding: 8px;

	}
	th{
		 padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #323299;
  color: white;
	}



	
</style>
<body>
<table>
	<tr>
		<th>ID</th>
		<th>FileName</th>
		<th>Action</th>
		
	</tr>


<?php

$conn=mysqli_connect("localhost","root","","elearning");
if($conn->connect_error){
	die("connection failed".$conn->connect_error);
}
$sql="Select id ,filename ,description from newfiles";
$result=$conn->query($sql);
if($result->num_rows >0){
	while($row=$result->fetch_assoc()){
		echo "<tr>";
		echo"<td>".$row['id']."</td>";
		echo "<td>".$row['filename']."</td>";
		echo "<td>" .$row['']."</td>";
		
		echo "</tr>";

	}
	echo "</table";
}else{
	echo "0 results";
}
$conn->close();

?>
</table>
</body>
</html>